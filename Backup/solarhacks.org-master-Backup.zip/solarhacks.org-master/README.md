# SolarHacks
Our Website: https://www.solarhacks.org

Join the Discord: https://discord.gg/xV9bDJg

Register for Solar Hacks I, taking place on October 19, 2019.

Solar Hacks is a one-day, 200-participant hackathon that is independent and unaffiliated with any school. Our goal is to bring middle and high school students in the Bay Area together to come together and develop innovative ideas that could revolutionize the world. At Solar Hacks, we provide students with the resources and mentorship that would be needed to convert their ideas into a reality. Additionally, by the end of the Hackathon, students will be able to learn how to collaborate with their peers to build STEM projects, gain presentation skills, and be inspired to continue doing things they love! Food, workshops, assistance, drinks, and swag will be provided to all participants for free!

We want all participants to enjoy their day at Solar Hacks, hence, we would encourage everybody to arrive to the Hackathon with a competitive mindset.



### What: 
SolarHacks is a high school hackathon in the Bay Area for students by students, and it's completely free! We will have free food, swag, goodies, and more! We will have plenty of games and icebreakers to make your experience memorable.

### Where:
We will be hosting the event at 42 Silicon Valley in Fremont, CA: 6600 Dumbarton Circle, Fremont, CA 94555

### When:
The event is an overnight hackathon on October 19th, 2019. The full schedule is available on our website.

### Who:
Anyone (as long as you're 18 or younger) can come, even if you haven't written a single line of code before! We will have plenty of opportunities for even non-coders to participate!

### Why:
There are tons of free food, swag, and goodies! You can make new friends and even learn some new skills you can show off to others. And plus, it's a free event! Bring along your friends to this wonderful free event.
